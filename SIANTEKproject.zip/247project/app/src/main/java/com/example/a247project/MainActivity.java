package com.example.a247project;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private CheckBox cmotor, cbrake, cshears;
    private Button BUSEL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
        /*
        addList();

        BUSEL.setOnClickListener(new View.OnClickListener() {
                                     @Override
                                     public void onClick(View v) {
                                         StringBuffer result = new StringBuffer();
                                         if (cmotor.isChecked() && cbrake.isChecked() && cshears.isChecked()) {
                                             Toast.makeText(MainActivity.this, "total price is 150", Toast.LENGTH_LONG).show();
                                         } else if (cmotor.isChecked() && cbrake.isChecked()) {
                                             Toast.makeText(MainActivity.this, "total price is 100", Toast.LENGTH_LONG).show();
                                         } else if (cmotor.isChecked() && cshears.isChecked()) {
                                             Toast.makeText(MainActivity.this, "total price is 100", Toast.LENGTH_LONG).show();
                                         } else if (cbrake.isChecked() && cshears.isChecked()) {
                                             Toast.makeText(MainActivity.this, "total price is 100", Toast.LENGTH_LONG).show();
                                         } else if (cmotor.isChecked()) {
                                             Toast.makeText(MainActivity.this, "total price is 50", Toast.LENGTH_LONG).show();
                                         } else if (cbrake.isChecked()) {
                                             Toast.makeText(MainActivity.this, "total price is 50", Toast.LENGTH_LONG).show();
                                         } else if (cshears.isChecked()) {
                                             Toast.makeText(MainActivity.this, "total price is 50", Toast.LENGTH_LONG).show();
                                         }


                                     }
                                 }
        );


    }

    public void addList() {
        cmotor = (CheckBox) findViewById(R.id.motor);
        cbrake = (CheckBox) findViewById(R.id.brake);
        cshears = (CheckBox) findViewById(R.id.shears);
        BUSEL = (Button) findViewById(R.id.button2);
    }*/


    public void area1(View view) {
        setContentView(R.layout.activity_profiler);

    }

    public void area2(View view) {
        setContentView(R.layout.activity_profiler);

    }

    public void area3(View view) {
        setContentView(R.layout.activity_profiler);
    }

    public void start(View view) {
        setContentView(R.layout.activity_main2);
    }

    public void signin(View view) {
        setContentView(R.layout.activity_craft);
        /* EditText user=(EditText)findViewById(R.id.username);
        EditText pass=(EditText)findViewById(R.id.password);
        Intent myintent1=new Intent(this,Main3.class);
        Bundle b=new Bundle();
        b.putString("username",user.getText().toString());
        b.putString("password",pass.getText().toString());
        myintent1.putExtras(b);
        startActivity(myintent1);*/
    }

    public void satellite(View view) {
        setContentView(R.layout.activity_area);
    }

    public void mechanic(View view) {
        setContentView(R.layout.activity_area);

    }

    public void plumber(View view) {
        setContentView(R.layout.activity_area);

    }




    public void signup(View view) {
        setContentView(R.layout.activity_main4);
    }


    public void profiler1(View view) {
        setContentView(R.layout.activity_pricing);
    }
    public void profiler2(View view) {
        setContentView(R.layout.activity_pricing);
    }
    public void profiler3(View view) {
        setContentView(R.layout.activity_pricing);
    }
    public void submitrate(View view) {
        setContentView(R.layout.activity_rating);
    }

    public void home(View view) {
        setContentView(R.layout.activity_main);

    }

}