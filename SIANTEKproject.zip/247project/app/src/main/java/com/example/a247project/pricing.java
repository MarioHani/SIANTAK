package com.example.a247project;

import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.widget.CheckBox;
import android.widget.Button;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class pricing extends AppCompatActivity {
    private CheckBox cmotor, cbrake, cshears;
    private Button BUSEL;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pricing);
        addList();
        BUSEL = (Button) findViewById(R.id.button2);
        BUSEL.setOnClickListener(new View.OnClickListener() {
                 @Override
                 public void onClick(View v) {
                     Log.i("checked", "onClick: Entered here");

                     if (cmotor.isChecked() && cbrake.isChecked() && cshears.isChecked()) {
                         Log.i("checked", "onClick: Entered here");
                         Toast.makeText(pricing.this, "total price is 150", Toast.LENGTH_LONG).show();
                     }  else if (cmotor.isChecked() && cbrake.isChecked()) {
                         Toast.makeText(pricing.this, "total price is 100", Toast.LENGTH_LONG).show();
                     }  else if (cmotor.isChecked() && cshears.isChecked()) {
                         Toast.makeText(pricing.this, "total price is 100", Toast.LENGTH_LONG).show();
                     }  else if (cbrake.isChecked() && cshears.isChecked()) {
                         Toast.makeText(pricing.this, "total price is 100", Toast.LENGTH_LONG).show();
                     } else  if (cmotor.isChecked()) {
                         Toast.makeText(pricing.this, "total price is 50", Toast.LENGTH_LONG).show();
                     }  else if (cbrake.isChecked()) {
                         Toast.makeText(pricing.this, "total price is 50", Toast.LENGTH_LONG).show();
                     }  else if (cshears.isChecked()) {
                         Toast.makeText(pricing.this, "total price is 50", Toast.LENGTH_LONG).show();
                     }


                 }
             }
        );


    }

    public void addList() {
        cmotor = (CheckBox) findViewById(R.id.motor);
        cbrake = (CheckBox) findViewById(R.id.brake);
        cshears = (CheckBox) findViewById(R.id.shears);
        BUSEL = (Button) findViewById(R.id.button2);
    }

    }

